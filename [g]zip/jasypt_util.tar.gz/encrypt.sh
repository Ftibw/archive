root_dir=$(cd `dirname $0`/..;pwd)
app_dir=${root_dir}/app
tool_dir=${root_dir}/tool

echo -n "Please enter your password:"
stty -echo
read content
stty echo
echo ""

echo -n "Please check your password:"
stty -echo
read content_cfr
stty echo
echo ""

if [ $content != $content_cfr ];then
	echo "different input error"
	exit 1
fi

DEFAULT_JASYPT_KEY=mOsiNFkfrnFEcaE
if [ -z $JASYPT_KEY ];then
	JASYPT_KEY=$DEFAULT_JASYPT_KEY
fi

DEFAULT_ALGORITHM=PBEWithMD5AndDES
if [ -z $ALGORITHM ];then
	ALGORITHM=$DEFAULT_ALGORITHM
fi

${tool_dir}/jdk/bin/java -cp ${app_dir}/jasypt-1.9.0.jar \
org.jasypt.intf.cli.JasyptPBEStringEncryptionCLI \
input="$content" \
password=${JASYPT_KEY} \
algorithm=${ALGORITHM} | awk 'NR==18{print $1}'

