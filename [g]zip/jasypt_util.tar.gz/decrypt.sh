root_dir=$(cd `dirname $0`/..;pwd)
app_dir=${root_dir}/app
tool_dir=${root_dir}/tool

content=$1
if [ -z $content ];then
	echo "script parameter to decrypt can not be empty!!!"
	exit 1
fi

DEFAULT_JASYPT_KEY=mOsiNFkfrnFEcaE
if [ -z $JASYPT_KEY ];then
	JASYPT_KEY=$DEFAULT_JASYPT_KEY
fi

DEFAULT_ALGORITHM=PBEWithMD5AndDES
if [ -z $ALGORITHM ];then
	ALGORITHM=$DEFAULT_ALGORITHM
fi

${tool_dir}/jdk/bin/java -cp ${app_dir}/jasypt-1.9.0.jar \
org.jasypt.intf.cli.JasyptPBEStringDecryptionCLI \
input="$content" \
password=${JASYPT_KEY} \
algorithm=${ALGORITHM} | awk 'NR==18{print $1}'

